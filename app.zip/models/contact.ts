export class Contact {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
}
