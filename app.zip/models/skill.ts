export class Skill {
}

