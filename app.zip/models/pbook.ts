export class Pbook {
  address: string;
  age: string;
  gender: string;
}
