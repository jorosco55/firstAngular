export class Message {

}
