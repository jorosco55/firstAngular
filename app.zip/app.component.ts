import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'The Republic';
  city = 'Phoenix';
  TagLine = 'For StarDust';
  AboutMe = 'like a man sailing the sea with no paddles attempting to light my last broken cigarette';
}
